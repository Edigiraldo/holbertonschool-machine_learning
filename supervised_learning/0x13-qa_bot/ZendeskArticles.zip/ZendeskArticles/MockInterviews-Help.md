Mock Interview Help
The interviewer is allowed to discuss and ask questions in order to help the candidate find the correct solution or to get more information when needed.
You can help the candidate on both the technical conversation and the code.
Subtract 0.1 point each time you helped the candidate find the correct or complete solution by asking questions. 
If you feel you are helping the candidate too much, guide them to the right answer as much as possible or give the answer in order to move the mock interview forward.