Active students in their 3rd trimester of the Foundations curriculum have access to the Github Student Developer Pack. 
This is a pack of tools and services curated by Github for students to use and learn.
Students can access this by going to the Tools section of the Intranet. 
Please Note: Students who apply for the Student Developer Pack through Github instead of the link provided by Holberton are not guaranteed access to the tools.