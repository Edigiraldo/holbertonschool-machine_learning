Specializations FAQ

“How does Holberton School ensure that year 2 curriculum is ‘industry standard’ ?''
The same as with Foundations, we involve a number of senior industry engineers and industry experts in the research, development, and implementation of the curriculum. Representing a variety of company types, industry needs, and technical priorities, these advisors contributions ensure students will be competitive once in the field of the choosing. 
There isn’t yet a quantifiable, commonly accepted metric of an “industry standard” - especially since software engineering is a vast field. However, by fielding the expertise of many advisors, we’re confident in this qualifiable assessment of quality.