Student Transfer FAQ
"What happens if a transfer is recommended by the School, but the student does not want to transfer or refuses to sign the transfer form?"
If the transfer was recommended by staff due to low scores (under 80% at the end of the trimester) the student would be dismissed per the student achievement policy, as listed in the Student Catalog.
"How many times can a student transfer?"
Students are allowed to transfer once within a trimester. For example, if a student in Cohort 8 needs to repeat their second trimester, they could transfer to Cohort 9’s second trimester. They, however, would not then be able to redo this same trimester by transferring to from Cohort 9 to Cohort 10. As such, they would be dismissed from the program due to their scores, per the student achievement policy. 
"Can a student transfer more than one cohort?"
It is not recommended for a student to transfer more than one cohort.