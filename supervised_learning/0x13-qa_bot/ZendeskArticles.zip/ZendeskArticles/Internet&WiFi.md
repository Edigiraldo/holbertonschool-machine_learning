Interwebs Overview
If you’re having trouble accessing the internet try the following before contacting staff. First, make sure that you are connecting to the network called ‘Holberton’. If you are having trouble connecting, try:
Change the EAP method you’re using to connect is ‘PEAP’.
Change your phase 2 authentication to ‘MSCHAPV2’.
Change CA certificate setting to ‘Don’t validate’.
Make sure that you’re using the correct username and password (that is your Holberton username and password).
If you’re connected to the WiFi but still unable to access the internet, check the IP address of the network you’re connected to. It should be 10.1.22.x for SF, and 10.2.22.x for NHV.
If all of the above is set correctly and you’re still having trouble connecting, first try restarting your connection. If it still doesn’t work, try restarting your computer.