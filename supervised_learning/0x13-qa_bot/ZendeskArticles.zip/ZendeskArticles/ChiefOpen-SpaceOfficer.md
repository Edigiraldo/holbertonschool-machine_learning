See also Chief Officer Duties
As Chief Open-Space Officer, your overall responsibility is to make sure that the learning space is maintained to a high standard.  As a community, we have to take care of our space. As a school we must look professional to visitors, investors, and other folks coming to visit us. It is expected that you will take responsibility to maintain the computer and desk you use at school. It is also your role to remind others to be mindful of their space and to keep it neat and clean.
List of duties:
At the end of each day, remove any personal items or trash from desks or meeting rooms. Relocate personal items to the lost and found. If they are valuable, please post to Slack and ask owner to claim by providing some details about where the item was found.
Monitor and enforce the food & drink policy - drinks must be in a sealed container (i.e., travel mugs, thermos, water bottle).
All non-occupied chairs are pushed in. Computer keyboards and mice are put back.
Markers and cleaning spray should be in each meeting room. If missing, make sure to tell students if they move it, they need to put it back. New whiteboard markers and erasers can be found at the front desk. Staffed security is aware of where they are stored, students may ask security for new markers & erasers.
Relocate any misplaced furniture back to its proper location.