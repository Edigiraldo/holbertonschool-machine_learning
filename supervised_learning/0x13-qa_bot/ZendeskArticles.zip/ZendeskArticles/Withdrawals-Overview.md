Withdrawals Overview
If a student expresses a desire to withdraw from the program they will request a withdrawal from the Institution Representative via in-person communication, followed by email and/or written letter.
Process
Once a student confirms by email their desire to withdraw from the program, the withdrawal confirmation paperwork will be sent to them via Docusign to confirm their:
Withdrawal confirmation date
Official Last Day of Attendance in the program
They will additionally be sent a Withdrawal Questionnaire to be filled out as a part of their withdrawal process.