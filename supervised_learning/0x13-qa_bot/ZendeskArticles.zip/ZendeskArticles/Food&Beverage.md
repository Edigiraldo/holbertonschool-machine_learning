Food & Beverage Policy
There is to be NO FOOD consumed outside of the Cantina;
The only beverages permitted outside of the Cantina need to be in a securely closed water bottle/coffee mug - NO paper or plastic cups, no re-usable cups without sealed lids are permitted outside of the Cantina;
 Food Storage Bin Rules
Each student has (2) 6-quart plastic bins. One to be used for the refrigerator, the other to be used for dry goods in the cabinets.
 If it doesn’t close, it goes! Since we have ~100 students storing food in our kitchen, we cannot accommodate more than what can fit in each bin with the lids securely closed.
Food and beverage items left outside of these containers are subject to be thrown out. If you happen to have a to-go container that does not fit, you can keep it refrigerated until the end of the day, but it cannot stay overnight.