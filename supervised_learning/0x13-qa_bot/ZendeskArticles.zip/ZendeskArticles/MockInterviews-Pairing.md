Mock Interview Pairing
Before the mock interview, students will be paired up via the intranet and they will interview each other.  
If you are late or absent, you must inform us via PTO on the intranet so that we can adjust the partner pairing, otherwise, it impacts your partner's interview time and it is unfair to them if you are not here when it's time to start.
A Note On Remote Mock Interviews
If you are doing your Mock Interview remotely, you or your partner will need to post the Google Meet link you use for the interview so staff can observe and offer support. This should be posted in the thread of the `Master Thread` message for the Mock Interview.