See also Chief Officer Duties
During the week, the Audio/Video Chief Officer will be in charge of setting up the Video/Sound system for the following:
Stand-up meetings: every day at 11:30 AM
Meetup events (if no one volunteers to do this for meetups, it will default to ChiefA/V Officer)
The Chief A/V Officer should meet with the student scheduled for the position next to brief them on how to set up all A/V equipment.