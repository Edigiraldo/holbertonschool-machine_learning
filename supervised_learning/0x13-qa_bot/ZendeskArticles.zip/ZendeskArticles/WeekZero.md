Week Zero Overview
Week Zero is not only your introduction to programming but also your introduction to Holberton School and our methodology and ethos. Everything you learn during Week Zero will be utilized throughout your time here as a student.
Week Zero Basics
Week Zero covers the following:
Technical Concepts
Vagrant
Github
Emacs
Vi(m)
Bash
Holberton Methodology
Learning How to Learn
The Framework
Peer Learning and Peer Learning Day (PLD)
Projects and Project-Based Learning
The Checker
Attendance and PTO
Soft Skills and Standup Presentations
Captain's Logs