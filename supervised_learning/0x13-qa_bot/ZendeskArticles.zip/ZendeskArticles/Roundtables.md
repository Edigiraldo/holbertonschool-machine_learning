At the beginning of every trimester, each cohort will gather together in small groups for a 30m Roundtable conversation to kick off the trimester together. 
Objective
The Roundtables create small support groups within the cohort and gives the supporting staff an opportunity to get to know the students beyond their technical project-work.
Scheduling
The Roundtables will be defined by the first PLD groups (with adjustments for absences). The groups meetings will be planned within the first couple of weeks in the trimester. They may span a couple days if there are more groups.
 
Trimester 1
Each person will be asked to introduce themselves by:
Sharing a bit about their background
Offer a way that they can help people
Ask for a way they can be supported
Trimester 2 & 3
Each person will be asked to share:
Their experience of the past trimester
What their personal goals are for the next trimester (or future)
Whether they have new offers or asks of their group