Also see Chief Officer Duties
As Chief Kitchen Officer, your overall responsibility is to make sure that the kitchen is maintained to a high standard. Below are pictures showing what the kitchen should look like most of the day, and, especially, at the end of each day. It is expected that you will need to delegate tasks to others to help maintain the kitchen.
Here is the list of duties that the Chief Kitchen Officer should be aware of:
Dishes must be dried, and put away in the designated space in the cupboards.
The sink must be kept clean and clear of food particles and liquid stains such as juice or coffee.
Microwave must be cleaned  both inside and outside at the end of every day
The Cantina tables need to be clean, positioned properly and have a disinfectant wipe dispenser available
Coffee machine must be cleaned at the end of every week.
Countertops should be wiped down/clear of any food residue.
Fridge:
Every Friday it must be emptied. Everybody has until 5pm that day to claim their food and place it back in the fridge. Any unclaimed or unlabeled food gets tossed in the garbage.
Remember to remove unclaimed leftovers and containers. 
Note: All cleaning supplies are under the sink.  If you need other supplies, please do not hesitate to ask the Office Manager.