Computer and Internet Usage Policy
There is to be no video game play at school before 6:00 PM on weekdays
The intranet is proprietary. Screenshots and copies of projects/assignments are strictly prohibited from being shared. (Please refer to the Intellectual Property - Ownership Policy in the Student Catalog);
Holberton communications (Slack messages, emails, Holberton produced slide decks, etc.) are considered confidential communications and are not permitted to be shared publicly. (Please refer to the Intellectual Property - Ownership Policy in the Student Catalog);
It is required to regularly check your Holberton accounts:
Messages via the intranet on a daily basis
Slack Messages
Emails in your Google account on a daily basis
We have a zero tolerance policy for torrenting illegal data. Torrenting at school could result in immediate dismissal.