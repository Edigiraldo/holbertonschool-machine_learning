Speaker of the Day
What is speaker of the day?
Every day at Standup, two randomly assigned students will be giving a three-minute presentation on a topic of their choice. There are three templates available as presentation options below.
The assigned students will receive their presentation date two weeks before the expected presentation via intranet and email. 
Presentations must be submitted to the appropriate Slack channel at least 24 hours in advance of the standup presentation. 
The purpose of this exercise is to practice and strengthen public speaking skills in a supportive environment.
Presentations cannot be about Religious or Political parties and views.
There will be Feedback Officers who will provide a manual review of each standup presentation. They will reflect upon various aspects of the delivery and content to help the Speaker of the Day improve.