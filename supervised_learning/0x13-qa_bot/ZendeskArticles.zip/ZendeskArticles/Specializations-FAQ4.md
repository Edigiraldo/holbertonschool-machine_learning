Specializations FAQ
 
“Have the Specializations been tested to ensure there aren’t any major bugs or technical discrepancies?” 
Absolutely, yet with that said, as you have likely noticed in Foundations (and we clarify during Day 0 orientation) you may encounter a bug; this is a reality of an ever-changing industry as well as curriculum that’s facilitated by software. That said, if you happen to discover a bug, the staff will immediately prioritize the matter to ensure that your education isn’t compromised. Akin to how many cohorts have improved the program up to this point, we’re looking forward to how future cohorts will encourage iterations in years to come by sharing their feedback. 
