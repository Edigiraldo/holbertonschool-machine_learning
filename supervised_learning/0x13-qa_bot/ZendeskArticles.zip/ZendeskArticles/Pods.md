The purpose of the Pods is to help students create social relationships with their peers and have a group of people they can schedule work sessions with or just hang out with. 
 
The Pods are virtual groups of about 8 students, automatically created, based on a short quiz on study/work habits.
 
The Pods are accessible via the intranet (from the conference rooms tab), attendance or usage is not mandatory, there is no grade related to the Pods.
 
Pods are going to be local only: students will be grouped by inside the campus and/or country.
 
The short quiz about study/work habits will be released some day before the Welcome party for students (in their intranet).
 
The Pods will be generated and presented to students during the Welcome party.