Printing Policy
The printer is located in the Copy Room: students have access to this room from 8am - 5pm 
Students can print a maximum of 30 pages per 30 days. If a student needs to print more pages, please contact the Office Manager via Slack (Direct Message)
Follow appropriate directions to add the printer to your computer
If you are having trouble syncing to the printer, please contact the Office Manager via Slack.
If paper or ink is needed to be refilled, please contact the Office Manager via Slack.