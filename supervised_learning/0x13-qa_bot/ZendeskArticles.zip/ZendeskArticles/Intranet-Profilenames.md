Student can define they preferred name in the Intranet. 
Preferred name is used for "How they want to address them" in Slack and Intranet. 
Students won't be able to edit by themselves first, middle and last names - they must ask staff for change.