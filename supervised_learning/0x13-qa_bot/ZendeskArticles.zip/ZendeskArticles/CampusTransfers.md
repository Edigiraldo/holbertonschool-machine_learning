Campus Transfer Overview
We love that this community spans time zones, cultures, and countries, and we want to foster the opportunity to collaborate as much as possible. 
At this given time, it is possible to transfer within the foundational part of the program depending on the campuses, if you have an 80% trimester average or higher, and if the transfer takes place during the break.
If you would like to complete your specialization at another campus please speak with your campus director and they’ll help you explore options.