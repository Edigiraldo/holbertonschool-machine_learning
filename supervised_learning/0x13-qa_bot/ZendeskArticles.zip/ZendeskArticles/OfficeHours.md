Office Hours are set weekly hours when students can drop-in to speak with staff members about anything.
Objective
Students are welcome to approach with questions, feedback or personal concerns. If the subject matter is sensitive (relating to scores, health issues, or personal challenges), students can request to move to a private meeting room.
Scheduling
There will be a minimum of 3 hours of Staff office hours per week. The office hour schedule and location will be announced in the #[location] Slack channel.
Location
The location for office hours can vary, but it will always be hosted in an open area.
 
Questions, Feedback, Concerns
Students are welcome to stop by to discuss any topic with Staff. Please follow the framework and first refer to PTO Frequently Asked Questions, Project Scoring, or questions around professional development.