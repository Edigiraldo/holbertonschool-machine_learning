Creating Space
If you do not already have a space to work from in your home, then it is best you create one if possible. 
Pick an area with the following qualities:
Quiet, has the least amount of distractions.
Big enough to fit a chair and desk.
Near a power source.
Has a strong Wi-Fi signal.
You want to make sure that you are not working in a place that is too comfortable, such as your bed, couch, or anywhere you’ve fallen asleep before!