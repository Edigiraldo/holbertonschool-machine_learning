At every Daily stand up, there will be some number (1-3) of Speaker of the Day presenters. Any student who is assigned to be Feedback Officer will need to post their manual review (below) in the #standup channel as a reply to each speaker's presentation link. 
If there are no Speaker of the Day presenters, then the Feedback Officer has no duty to provide feedback.
If a Feedback Officer does not provide their manual review within 3 hours of standup, then they will receive -5% on their professional score. 
 This is the manual review criteria:
Presentation Delivery:
Was the Presenter audible?
Did the Presenter speak clearly and at an understandable pace?
Were there minimal filler words, like "Uhm", "uhh", "like"?
Did the Presenter regularly make eye contact with the audience?
Was the Presenter well-positioned onstage?
Did the Presenter’s posture demonstrate confidence?
Was the Presenter dressed professionally?
Did the presentation utilize the 3min? (it was not too long, or too short)
Was the speaker energetic?
Did the speaker engage with the audience with a question?
What was one thing the Presenter could have done better for their presentation delivery?
Content:
Was the topic one of the templated options? (Brief History of Myself, Working as a __ at ___, or a Technical Topic)
Did the presentation slides include appropriate and relevant photos/diagrams?
Did you understand the speaker’s connection to their chosen topic?
Was the information presented in a clear and organized way?
What was one thing the Presenter could have done better for their presentation content?