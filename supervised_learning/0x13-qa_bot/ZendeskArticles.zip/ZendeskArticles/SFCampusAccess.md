Students have 24/7 access to the SF campus while they are students in San Francisco.
Once students graduate, they will be granted lifetime access to the SF campus. 
Holberton reserves the right to revoke access to any student on any campus for any reason. Students may appeal this decision and, if curable, may be given the opportunity to reinstate their access.