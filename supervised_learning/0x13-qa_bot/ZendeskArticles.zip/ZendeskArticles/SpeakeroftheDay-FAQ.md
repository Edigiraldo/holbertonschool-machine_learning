Speaker of the Day FAQ
How do I switch Speaker of the Day presentation slots? 
Students can switch Speaker of the Day presentation slots on the Intranet under “Speaker of the Day”
How long do I have to change my Speaker of the Day presentation slot?
Students have 72 hours (3 days) before their scheduled presentation slot to change their Speaker of the Day presentation slot. Any request after 72 hours can result in losing professional points that will affect ones professional score at the end of the trimester.
Do I still have to fulfill my Speaker of the Day duty if it lands on a project day (a non-mandatory day)?
Yes, Speaker of the Day is a mandatory assignment that will affect students professional track if not completed.
If I can't find anyone to switch with me and I know I will not be able to present on the schedule presentation day what should I do next? 
Use a .5 PTO or risk losing points off of the Professional track
What staff member do I contact if I am unable to switch Speaker of the Day presentation slots?
You will contact the Office Manager or the Student Success Manager.
What if my presentation is about Religious or Political parties and views?
If students do not follow topic guidelines they will not receive the professional points
Do I need to dress professionally when I give my presentation? 
It is one of the criteria for the Feedback Officers to evaluate, however it is not required to dress professionally when giving ones Speaker of the Day presentation. In the real world, interviews and public speaking generally require more presentable attire.