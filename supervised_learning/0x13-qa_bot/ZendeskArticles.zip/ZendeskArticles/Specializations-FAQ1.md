Specializations FAQ

"Can I study and work at the same time?"
No, we strongly discourage this. We understand that you may need to do so regardless, but please note that the Specialization will require a lot of work.

"What if I want to study and search for a job?"
We believe that both of these endeavors require focused attention in order to ideally succeed. Please, undertake Specialization studies if you can prioritize it so that you can get the most out of your experience.
 
"What are the grade expectations?"
Same as Foundations, you must maintain and achieve an 80% in order to proceed to the next trimester in the program. 
 
"Are there mock interviews and PLDs?"
Yes! As of January 2020, they have been integrated due to high student request and demand; we're excited and pleased ourselves ; ) 
 
"What are the project days like?"
Unlike Foundations, the majority of the Specialization projects are longer and go more in-depth. As always, you can collaborate with peers however works best for you and them.
